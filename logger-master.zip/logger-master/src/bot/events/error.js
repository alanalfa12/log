module.exports = {
  name: 'error',
  type: 'on',
  handle: console.error
}
