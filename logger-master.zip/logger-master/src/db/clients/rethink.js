// const Dash = require('rethinkdbdash')

// require('dotenv').config()

// const r = new Dash({
//   user: process.env.RETHINK_USERNAME,
//   password: process.env.RETHINK_PASSWORD || '',
//   silent: true,
//   servers: [{
//     host: 'localhost',
//     port: '28015'
//   }]
// })

// module.exports = r
